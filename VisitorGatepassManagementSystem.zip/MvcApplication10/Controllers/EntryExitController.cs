﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using System.Data;
using System.Dynamic;

namespace MvcApplication10.Controllers
{
    public class EntryExitController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        public ActionResult EntryExitList()
        {
            List<EntryExitList> EntryExitListRecords = new List<EntryExitList>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("[EntryExitList]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<EntryExitList> EntryExitList = new List<EntryExitList>();

                foreach (DataRow row in dt.Rows)
                {
                    EntryExitList visitor = new EntryExitList();
                    visitor.EntryExitID = Convert.ToInt32(row["EntryExitID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();
                    visitor.VisitorCompany = row["CompanyName"].ToString();
                    


                   

                    EntryExitList.Add(visitor);
                }

                return View(EntryExitList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<EntryExitList>());
            }
        }

        public ActionResult EntryExit()
        {
            EntryExit litid = new EntryExit();

            return View(litid);
        }
        [HttpPost]
        public JsonResult EntryExit(string IDNumber = "")
        {
            EntryExit Visitorcompanyobj = new EntryExit();

            string dynamicvalue = IDNumber;
            string transType = "";

            if (dynamicvalue.Contains('A'))
            {
                //string TranIDValue = dynamicvalue.Remove(0, 3);
                transType = "1";
            }
            if (dynamicvalue.Contains('S'))
            {
                //    string TranIDValue = dynamicvalue.Remove(0, 1);
                transType = "2";
            }
            if (dynamicvalue.Contains('M'))
            {
                //string TranIDValue = dynamicvalue.Remove(0, 5);
                transType = "3";
            }

            Visitorcompanyobj = GetUpdateEntryExit(IDNumber, Convert.ToInt32(transType), Visitorcompanyobj.VisitorName);

            return Json(Visitorcompanyobj);
        }

        public EntryExit GetUpdateEntryExit(string IDNumber = "", int TranscationType = 0, string VisitorName = "", string VisitorCompany = "")
        {
            EntryExit Visitorcompanyobj = new EntryExit();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("ExitentryVisit", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IDNumber", IDNumber);
                cmd.Parameters.AddWithValue("@TranscationType", TranscationType);


                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Visitorcompanyobj.IDNumber = reader["IDNumber"].ToString();

                    Visitorcompanyobj.VisitorName = reader["VisitorName"].ToString();
                    Visitorcompanyobj.VisitorCompany = reader["CompanyName"].ToString();
                    //Visitorcompanyobj.EntryExitType = reader["EntryExitType"].ToString();
                }
                con.Close();
                return Visitorcompanyobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new EntryExit();
            }
        }

        //PasEntryExit
        public ActionResult PassEntryExit()
        {
            PassEntryExit litid = new PassEntryExit();
            return View(litid);
        }

        [HttpPost]

        public JsonResult PassEntryExit(int EntryExitType, string IDNumber)
        {
            PassEntryExit Visitorcompanyobj = new PassEntryExit();

            string dynamicvalue = IDNumber ?? "0";
            string PAssType = "";

            if (dynamicvalue.Contains('A'))
            {
                PAssType = "1";
            }
            if (dynamicvalue.Contains('S'))
            {
                PAssType = "2";
            }
            if (dynamicvalue.Contains('M'))
            {
                PAssType = "3";
            }

            // Assuming GetUpdateEntryExit method signature is: GetUpdateEntryExit(int, int, int, string)
            String ErrorMessage = GetUpdateEntryExit(EntryExitType, Convert.ToInt32(PAssType), dynamicvalue);

            return Json(ErrorMessage);
        }

        public string GetUpdateEntryExit(int EntryExitType, int PassType, string IDNumber)
        {
            PassEntryExit Visitorcompanyobj = new PassEntryExit();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("[EntryExitPass]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EntryExitType", EntryExitType);
                cmd.Parameters.AddWithValue("@PassType", PassType);
                //cmd.Parameters.AddWithValue("@RefID", RefID);
                cmd.Parameters.AddWithValue("@IDNumber", IDNumber);
                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                //SqlDataReader reader = cmd.ExecuteReader();
                //if (reader.Read())
                //{
                //    Visitorcompanyobj.EntryExitType = Convert.ToInt32(reader["EntryExitType"]);
                //    Visitorcompanyobj.PassType = Convert.ToInt32(reader["PassType"]);
                //    Visitorcompanyobj.RefID = Convert.ToInt32(reader["RefID"]);
                //    Visitorcompanyobj.IDNumber = reader["IDNumber"].ToString();
                //}
                //reader.Close(); 
                cmd.ExecuteNonQuery(); 

                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
                return ReturnOutput;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return "";
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}
