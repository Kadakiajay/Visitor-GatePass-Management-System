﻿using System.Web.Mvc;

namespace MvcApplication10.Areas.Sql_server_databse
{
    public class Sql_server_databseAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Sql_server_databse";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Sql_server_databse_default",
                "Sql_server_databse/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
