﻿using System.Web.Mvc;

namespace MvcApplication10.Areas.image
{
    public class imageAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "image";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "image_default",
                "image/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
