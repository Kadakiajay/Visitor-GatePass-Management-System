﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication10.Models
{
    public class Login
    {
        public int loginID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
       
            //public string name { get; set; }
        public string ReturnOutput { get; set; }
    }
    //forgot password
    public class Forgot
    {
        public int UserID { get; set; }
        public int Emailid { get; set; }
        public string ReturnOutput { get; set; }

    }
    //UserRegistration
    public class UserRegistration
    {

        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string ContactNumber { get; set; }
        public string Address { get; set; }
        public string PinNumber { get; set; }
        public string Password { get; set; }
        public string RetypePassword { get; set; }
        public string ReturnOutput { get; set; }
    }

}

