﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MvcApplication10.Controllers
{
    public class RegistrationController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);




        public ActionResult Registration()
        {
            //{
            //    int UID = litid.UserID;
            //    string VisitorName = litid.VisitorName;
            //    string VisitorEmail = litid.VisitorEmail;
            //    string VisitorCompony = litid.VisitorCompony;
            //    string PurposeOfVisit = litid.PurposeOfVisit;
            //    string ContactNumber = litid.ContactNumber;
            //    string CheckinDate = litid.CheckinDate;
            //    string CheckinTime = litid.CheckinTime;
            //    string Address = litid.Address;
            //    string Password = litid.Password;
            //    string RetypePassword = litid.RetypePassword;

            //con.Open();
            //if ((con.State & ConnectionState.Open) > 0)
            //{

            //    //Response.Write(" connection ok !");
            //    con.Close();
            //}
            //else
            //{
            //    //Response.Write("  no connection  !");
            //    con.Close();
            //}
            //UserData udata = new UserData();
            //udata.ReturnOutput = "";
            Registration litid = new Registration();
            return View(litid);
            //}



        }

        //GET: /registration/
        [HttpPost]
        public ActionResult Registration(Registration litid)
        {

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("ALLreacords", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@VisitorName", litid.VisitorName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@VisitorEmail", litid.VisitorEmail ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@VisitorCompany", litid.VisitorCompany ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@PurposeOfVisit", litid.PurposeOfVisit ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ContactNumber", litid.ContactNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@CheckinDate", litid.CheckinDate);
                cmd.Parameters.AddWithValue("@CheckinTime", litid.CheckinTime);
                cmd.Parameters.AddWithValue("@Address", litid.Address ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Password", litid.Password ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@RetypePassword", litid.RetypePassword ?? (object)DBNull.Value);
                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();

                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
                if (ReturnOutput == "Registration successful")
                {
                    ViewBag.Notification = "Registration successful!";
                }
                else
                {
                    ViewBag.Notification = "Registration failed. Please check your username and password.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }
            return View(litid);


        }
    }
}


