﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class UserRegistrationList : Controller
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string ContactNumber { get; set; }
        public string Address { get; set; }
        public string PinNumber { get; set; }
        public string Password { get; set; }
        public string RetypePassword { get; set; }

    }
    public class UpdateRegistration
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string ContactNumber { get; set; }
        public string Address { get; set; }
        public string PinNumber { get; set; }
        public string Password { get; set; }
        public string RetypePassword { get; set; }



    }
}

