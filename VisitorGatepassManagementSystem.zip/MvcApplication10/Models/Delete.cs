﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class Delete
    {
        public int DeleteID { get; set; }
        public string Delteid { get; set; }
        public string DeleteUserid { get; set; }
        public string DeleteCompanyID { get; set; }
        public string DeleteVisitorID { get; set; }
        public string DeleteAppoitmentID { get; set; }
        //public string DeleteSingledayID { get; set; }
        public string DeleteMultipledayID { get; set; }
      
     
    }
    
}


    

