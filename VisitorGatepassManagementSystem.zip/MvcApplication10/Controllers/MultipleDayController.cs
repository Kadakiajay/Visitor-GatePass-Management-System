﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;



namespace MvcApplication10.Controllers
{
    public class MultipleDayController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        public ActionResult MultipleDayList()
        {
            List<MultipleDayList> MultipleDayListRecords = new List<MultipleDayList>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("ListMultipleDay", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("@VisitorID", 0);
                //cmd.Parameters.AddWithValue("@VisitorName", "");
                //cmd.Parameters.AddWithValue("@VisitorType", "");
                //cmd.Parameters.AddWithValue("@VisitorCompany", "");
                //cmd.Parameters.AddWithValue("@FromDate", "");
                //cmd.Parameters.AddWithValue("@TODate", "");
                //cmd.Parameters.AddWithValue("@City", "");
                //cmd.Parameters.AddWithValue("@ContactNumber", "");



                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<MultipleDayList> MultipleDayList = new List<MultipleDayList>();

                foreach (DataRow row in dt.Rows)
                {
                    MultipleDayList Visitor = new MultipleDayList();
                    Visitor.MultipledayID = Convert.ToInt32(row["MultipledayID"]);
                    Visitor.VisitorName = row["VisitorName"].ToString();
                    Visitor.VisitorType = row["VisitorType"].ToString();
                    Visitor.VisitorCompany = row["CompanyName"].ToString();
                    Visitor.FromDate = row["FromDate"].ToString();
                    Visitor.TODate = row["TODate"].ToString();
                    Visitor.City = row["City"].ToString();
                    Visitor.ContactNumber = row["ContactNumber"].ToString();
                    Visitor.IDNumber = row["IDNumber"].ToString();
                    MultipleDayList.Add(Visitor);
                }

                return View(MultipleDayList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<MultipleDayList>());
            }
        }
        //Multipleday
        public ActionResult MultipleDay()
        {
            MultipleDay litid = new MultipleDay();
            litid.lstMultipleDropdown = DropVisitor();
            litid.lstMultipleCompanyDropdown = DropDownVisitorCompany();
            return View(litid);
        }

        [HttpPost]
        public ActionResult MultipleDay(MultipleDay litid)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("DayMultiple", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VisitorName", litid.MultipledayID);
                cmd.Parameters.AddWithValue("@VisitorType", litid.VisitorType ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@VisitorCompany", litid.VisitorCompany ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@FromDate", litid.FromDate);
                cmd.Parameters.AddWithValue("@TODate", litid.TODate);
                cmd.Parameters.AddWithValue("@ContactNumber", litid.ContactNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@City", litid.City ?? (object)DBNull.Value);

                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                litid.lstMultipleDropdown = DropVisitor();
                litid.lstMultipleCompanyDropdown = DropDownVisitorCompany();

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "MultipleDay Pass Gennrate Successful";
                }
                else
                {
                    ViewBag.Notification = "User already exists";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred: " + ex.Message;
            }
            return View(litid);
        }
        //Drop multiple

        public List<DropDownVisitor> DropVisitor()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> DropVisitor = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();

                    visitor.VisitorType = row["VisitorType"].ToString();

                    DropVisitor.Add(visitor);
                }

                return DropVisitor;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }
        }
        //dropdownvisitorcompany
        public List<DropDownVisitorCompany> DropDownVisitorCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropdownCompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownVisitorCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();
                    DropDownVisitorCompany.Add(visitor);
                }


                return DropDownVisitorCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }

        //UpdateMultipleday
        public ActionResult UpdateMultipleday(int MultipledayID = 0)
        {
            MultipleDay Visitorcompanyobj = new MultipleDay();
            Visitorcompanyobj = GetUpdateMultipleData(MultipledayID);
            Visitorcompanyobj.lstMultipleDropdownupdate = Dropmultiple();
            Visitorcompanyobj.lstMultipleCompanyDropdownupdate = DropDownmultipleCompany();
            return View(Visitorcompanyobj);
        }

        public MultipleDay GetUpdateMultipleData(int MultipledayID)
        {
            MultipleDay Visitorcompanyobj = new MultipleDay();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Multiple_selectone", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MultipledayID", MultipledayID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Visitorcompanyobj.MultipledayID = Convert.ToInt32(reader["MultipledayID"]);
                    Visitorcompanyobj.VisitorID = Convert.ToInt32(reader["VisitorID"]);
                    Visitorcompanyobj.VisitorType = reader["VisitorType"].ToString();
                    Visitorcompanyobj.VisitorCompany = reader["VisitorCompany"].ToString();
                    Visitorcompanyobj.FromDate = Convert.ToDateTime(reader["FromDate"]);
                    Visitorcompanyobj.TODate = Convert.ToDateTime(reader["TODate"]);

                    Visitorcompanyobj.ContactNumber = reader["ContactNumber"].ToString();
                    Visitorcompanyobj.City = reader["City"].ToString();

                }

                return Visitorcompanyobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new MultipleDay();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
        [HttpPost]
        public ActionResult UpdateMultipleday(MultipleDay Visitorcompanyobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("UpdateMUltipleDay", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MultipledayID", Visitorcompanyobj.MultipledayID);
                cmd.Parameters.AddWithValue("@VisitorName", Visitorcompanyobj.VisitorID);
                cmd.Parameters.AddWithValue("@VisitorType", Visitorcompanyobj.VisitorType);
                cmd.Parameters.AddWithValue("@VisitorCompany", Visitorcompanyobj.VisitorCompany);
                cmd.Parameters.AddWithValue("@FromDate", Visitorcompanyobj.FromDate);
                cmd.Parameters.AddWithValue("@TODate", Visitorcompanyobj.TODate);
                cmd.Parameters.AddWithValue("@ContactNumber", Visitorcompanyobj.ContactNumber);
                cmd.Parameters.AddWithValue("@City", Visitorcompanyobj.City);
                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                Visitorcompanyobj.lstMultipleDropdownupdate = Dropmultiple();
                Visitorcompanyobj.lstMultipleCompanyDropdownupdate = DropDownmultipleCompany();

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();


                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }

            return View(Visitorcompanyobj);

        }
        //Drop multiple
        public List<DropDownVisitor> Dropmultiple()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> Dropmultiple = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();
                    visitor.VisitorType = row["VisitorType"].ToString();
                    Dropmultiple.Add(visitor);
                }

                //SelectList VisitorList = new SelectList(DropDownVisitor, "VisitorID", "VisitorName");

                return Dropmultiple;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }

        }


        //dropdownvisitorcompany
        public List<DropDownVisitorCompany> DropDownmultipleCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropdownCompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                con.Close();

                List<DropDownVisitorCompany> DropDownmultipleCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();

                    DropDownmultipleCompany.Add(visitor);
                }

                return DropDownmultipleCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }

        }
    }

}




