﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class Registration 
    {
        public int UserID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public string VisitorCompany { get; set; }
        public string PurposeOfVisit { get; set; }
        public string ContactNumber { get; set; } 
        public  DateTime  CheckinDate { get; set; }
        public  DateTime  CheckinTime { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string RetypePassword { get; set; }
        public string ReturnGatepass { get; set; }
    }
}
