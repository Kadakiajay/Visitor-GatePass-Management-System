﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace MvcApplication10.Controllers
{
    public class SingleDayController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        public ActionResult SingleDayList()
        {
            List<SingleDayList> SingleDayListRecords = new List<SingleDayList>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("ListSingleDay", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("@VisitorID", 0);
                //cmd.Parameters.AddWithValue("@VisitorName", "");
                //cmd.Parameters.AddWithValue("@VisitorCompany", "");
                //cmd.Parameters.AddWithValue("@VisitorType", "");
                //cmd.Parameters.AddWithValue("@City", "");
                //cmd.Parameters.AddWithValue("@ContactNumber", "");
                //cmd.Parameters.AddWithValue("@ExpectedDuration", "");
                //cmd.Parameters.AddWithValue("@PurposeOfVisit", "");



                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<SingleDayList> SingleDayList = new List<SingleDayList>();

                foreach (DataRow row in dt.Rows)
                {
                    SingleDayList Visitor = new SingleDayList();
                    Visitor.SingledayID = Convert.ToInt32(row["SingledayID"]);
                    Visitor.VisitorName = row["VisitorName"].ToString();
                    Visitor.VisitorCompany = row["CompanyName"].ToString();
                    Visitor.VisitorType = row["VisitorType"].ToString();
                    Visitor.City = row["City"].ToString();
                    Visitor.ContactNumber = row["ContactNumber"].ToString();
                    Visitor.ExpectedDuration = row["ExpectedDuration"].ToString();
                    Visitor.PurposeOfVisit = row["PurposeOfVisit"].ToString();
                    Visitor.IDNumber = row["IDNumber"].ToString();
                    SingleDayList.Add(Visitor);
                }

                return View(SingleDayList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<SingleDayList>());
            }


        }
        //Create SingleDay

        public ActionResult SingleDay()
        {
            SingleDay litid = new SingleDay();
            litid.lstSingleDropdown = DropDownVisitor();
            litid.lstSingleCompanyDropdown = DropDownVisitorCompany();

            return View(litid);
        }
        [HttpPost]
        public ActionResult SingleDay(SingleDay litid)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("daysinlge", con);

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@VisitorName", litid.VisitorID);

                cmd.Parameters.AddWithValue("@VisitorCompany", litid.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorType", litid.VisitorType);

                cmd.Parameters.AddWithValue("@City", litid.City ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ContactNumber", litid.ContactNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ExpectedDuration", litid.ExpectedDuration);
                cmd.Parameters.AddWithValue("@PurposeOfVisit", litid.PurposeOfVisit ?? (object)DBNull.Value);
                //Guid idNumberGuid = Guid.Parse(litid.IDNumber);
                //cmd.Parameters.Add("@IDNumber", SqlDbType.UniqueIdentifier).Value = litid.
                //    IDNumber;

                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;
                litid.lstSingleDropdown = DropDownVisitor();
                litid.lstSingleCompanyDropdown = DropDownVisitorCompany();

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = " SIngleDay Registration Successful";

                }

                else
                {
                    ViewBag.Notification = "User already exists";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }
            return View(litid);

        }
        //DropdownSingle
        public List<DropDownVisitor> DropDownVisitor()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> DropDownVisitor = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();

                    visitor.VisitorType = row["VisitorType"].ToString();

                    DropDownVisitor.Add(visitor);
                }

                return DropDownVisitor;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }
        }
        //DropDownCompay

        public List<DropDownVisitorCompany> DropDownVisitorCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Dropdowncompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownVisitorCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();

                    DropDownVisitorCompany.Add(visitor);
                }

                return DropDownVisitorCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }


        //updateSingleday   

        public ActionResult UpdateSingleday(int SingledayID = 0)
        {
            SingleDay Visitorcompanyobj = new SingleDay();
            Visitorcompanyobj = GetUpdateSingleData(SingledayID);
            Visitorcompanyobj.lstSingleDropdownUpdate = DropVisitor();
            Visitorcompanyobj.lstSingleDropdowncomUpdate = DropDownCompany();

            return View(Visitorcompanyobj);
        }


        public SingleDay GetUpdateSingleData(int SingledayID)
        {
            SingleDay Visitorcompanyobj = new SingleDay();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Singleday_selectone", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SingledayID", SingledayID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Visitorcompanyobj.SingledayID = Convert.ToInt32(reader["SingledayID"]);
                    Visitorcompanyobj.VisitorCompany = Convert.ToInt32(reader["VisitorCompany"].ToString());
                    Visitorcompanyobj.VisitorID = Convert.ToInt32(reader["VisitorID"].ToString());
                    Visitorcompanyobj.VisitorType = Convert.ToInt32(reader["VisitorType"].ToString());
                    Visitorcompanyobj.City = reader["City"].ToString();
                    Visitorcompanyobj.ContactNumber = reader["ContactNumber"].ToString();
                    Visitorcompanyobj.ExpectedDuration = TimeSpan.Parse(reader["ExpectedDuration"].ToString());
                    Visitorcompanyobj.PurposeOfVisit = reader["PurposeOfVisit"].ToString();
                    //Visitorcompanyobj.IDNumber = reader["IDNumber"].ToString();
                }

                return Visitorcompanyobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new SingleDay();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        [HttpPost]
        public ActionResult UpdateSingleday(SingleDay Visitorcompanyobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("UpdateSingleday", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SingledayID", Visitorcompanyobj.SingledayID);
                cmd.Parameters.AddWithValue("@VisitorName", Visitorcompanyobj.VisitorID);
                cmd.Parameters.AddWithValue("@VisitorCompany", Visitorcompanyobj.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorType", Visitorcompanyobj.VisitorType);
                cmd.Parameters.AddWithValue("@City", Visitorcompanyobj.City);
                cmd.Parameters.AddWithValue("@ContactNumber", Visitorcompanyobj.ContactNumber);
                cmd.Parameters.AddWithValue("@ExpectedDuration", Visitorcompanyobj.ExpectedDuration);
                cmd.Parameters.AddWithValue("@PurposeOfVisit", Visitorcompanyobj.PurposeOfVisit);

                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                Visitorcompanyobj.lstSingleDropdownUpdate = DropDownVisitor();
                Visitorcompanyobj.lstSingleDropdowncomUpdate = DropDownVisitorCompany();

                cmd.ExecuteNonQuery();


                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }

            return View(Visitorcompanyobj);

        }

        //DropdownSingle
        public List<DropDownVisitor> DropVisitor()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> DropVisitor = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();

                    visitor.VisitorType = row["VisitorType"].ToString();

                    DropVisitor.Add(visitor);
                }

                return DropVisitor;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }



        }
        //Dropdowncompany
        public List<DropDownVisitorCompany> DropDownCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropdownCompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();

                    DropDownCompany.Add(visitor);
                }

                return DropDownCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }

    }
}