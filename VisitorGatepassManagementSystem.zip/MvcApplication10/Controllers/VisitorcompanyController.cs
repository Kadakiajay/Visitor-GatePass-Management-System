﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;

namespace MvcApplication10.Controllers
{
    public class VisitorcompanyController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
        //Visitor company list
        public ActionResult VisitorcompanyList()
        {
            List<VisitorcompanyList> VisitorcompanyListRecords = new List<VisitorcompanyList>();
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("ListVisitorcompany", con);
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@CompanyName", "");
                cmd.Parameters.AddWithValue("@CompanyEmail", "");
                cmd.Parameters.AddWithValue("@CompanyAddress", "");
                cmd.Parameters.AddWithValue("@CompanyPhone", "");
                cmd.Parameters.AddWithValue("@PinCode", "");
                cmd.Parameters.AddWithValue("@City", "");
                cmd.Parameters.AddWithValue("@State", "");
                cmd.Parameters.AddWithValue("@Country", "");
                cmd.Parameters.AddWithValue("@GSTNUMBER", "");




                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<VisitorcompanyList> VisitorcompanyList = new List<VisitorcompanyList>();

                foreach (DataRow row in dt.Rows)
                {
                    VisitorcompanyList company = new VisitorcompanyList();
                    company.CompanyID = Convert.ToInt32(row["CompanyID"]);
                    company.CompanyName = row["CompanyName"].ToString();
                    company.CompanyEmail = row["CompanyEmail"].ToString();
                    company.CompanyAddress = row["CompanyAddress"].ToString();
                    company.CompanyPhone = row["CompanyPhone"].ToString();
                    company.PinCode = row["PinCode"].ToString();
                    company.City = row["City"].ToString();
                    company.State = row["State"].ToString();
                    company.Country = row["Country"].ToString();
                    company.GSTNUMBER = row["GSTNUMBER"].ToString();
                    VisitorcompanyList.Add(company);
                }

                return View(VisitorcompanyList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<VisitorcompanyList>());
            }
        }
        ////DeleteCompany
        //public class DeleteController : Controller
        //{
        //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        //    public ActionResult Delete()
        //    {
        //        Delete list = new Delete();
        //        return View(list);
        //    }
        //    [HttpPost]
        //    public JsonResult Delete(int CompanyID)
        //    {
        //        try
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("Deletelist", con);
        //            cmd.CommandType = CommandType.StoredProcedure;

        //            cmd.Parameters.AddWithValue("@CompanyID", CompanyID);

        //            cmd.ExecuteNonQuery();
        //            con.Close();

        //            return Json(new { success = true, message = "Visitor deleted successfully." });
        //        }
        //        catch (Exception ex)
        //        {
        //            // Log the error or handle it appropriately
        //            return Json(new { success = false, message = "Error deleting visitor: " + ex.Message });
        //        }
        //    }

        //Visitorcompany Registration
        public ActionResult Visitorcompany()
        {
            Visitorcompany litid = new Visitorcompany();

            return View(litid);
        }
        //CreateVIsitor
        [HttpPost]

        public ActionResult Visitorcompany(Visitorcompany litid)
        {

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("CompnanyVisitor", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CompanyName", litid.CompanyName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@CompanyEmail", litid.CompanyEmail ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@CompanyAddress", litid.CompanyAddress ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@CompanyPhone", litid.CompanyPhone ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@PinCode", litid.PinCode ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@City", litid.City ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@State", litid.State ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Country", litid.Country ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@GSTNUMBER", litid.GSTNUMBER ?? (object)DBNull.Value);


                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = " Visitorcompany Registration Successful";
                }
                else
                {
                    ViewBag.Notification = "User already exists";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }
            return View(litid);

        }

        //UpdateCompany
        public ActionResult UpdateCompany(int CompanyID = 0)
        {
            Visitorcompany Visitorcompanyobj = new Visitorcompany();
            Visitorcompanyobj = GetUpdatecompanyData(CompanyID);
            return View(Visitorcompanyobj);
        }

        public Visitorcompany GetUpdatecompanyData(int CompanyID)
        {
            Visitorcompany Visitorcompanyobj = new Visitorcompany();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Company_SelectOne", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CompanyID", CompanyID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    //Visitorcompanyobj.CompanyID = Convert.ToInt32(reader["CompanyID"]);
                    Visitorcompanyobj.CompanyName = reader["CompanyName"].ToString();
                    Visitorcompanyobj.CompanyEmail = reader["CompanyEmail"].ToString();
                    Visitorcompanyobj.CompanyAddress = reader["CompanyAddress"].ToString();
                    Visitorcompanyobj.CompanyPhone = reader["CompanyPhone"].ToString();
                    Visitorcompanyobj.PinCode = reader["PinCode"].ToString();
                    Visitorcompanyobj.City = reader["City"].ToString();
                    Visitorcompanyobj.State = reader["State"].ToString();
                    Visitorcompanyobj.Country = reader["Country"].ToString();
                    Visitorcompanyobj.GSTNUMBER = reader["GSTNUMBER"].ToString();

                }
                con.Close(); // Close the connection
                return Visitorcompanyobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new Visitorcompany();
            }
        }
        [HttpPost]
        public ActionResult UpdateCompany(Visitorcompany Visitorcompanyobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("CompanyUpdate", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CompanyID", Visitorcompanyobj.CompanyID);
                cmd.Parameters.AddWithValue("@CompanyName", Visitorcompanyobj.CompanyName);
                cmd.Parameters.AddWithValue("@CompanyEmail", Visitorcompanyobj.CompanyEmail);
                cmd.Parameters.AddWithValue("@CompanyAddress", Visitorcompanyobj.CompanyAddress);
                cmd.Parameters.AddWithValue("@CompanyPhone", Visitorcompanyobj.CompanyPhone);
                cmd.Parameters.AddWithValue("@PinCode", Visitorcompanyobj.PinCode);
                cmd.Parameters.AddWithValue("@City", Visitorcompanyobj.City);
                cmd.Parameters.AddWithValue("@State", Visitorcompanyobj.State);
                cmd.Parameters.AddWithValue("@Country", Visitorcompanyobj.Country);
                cmd.Parameters.AddWithValue("@GSTNUMBER", Visitorcompanyobj.GSTNUMBER);


                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "Not Updated";
            }

            return View(Visitorcompanyobj);
        }
    }
}



