﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class VisitorRegistration
    {

        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public int VisitorCompany { get; set; }
        public string VisitorType { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string ContactNumber { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public List<DropDownVisitorCompany> lstVisitorCompanyDropdown { get; set; }
        public List<DropDownVisitorCompany> lstVisitorDropdowncomUpdate { get; set; }
        //public List<DropDownVisitorCompany> lstVisitorCompanyDropdown { get; set; }
  
    }

    public class Visitorlist
    {
        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public string VisitorCompany { get; set; }
        public string VisitorType { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string ContactNumber { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }
  
    
    
}
