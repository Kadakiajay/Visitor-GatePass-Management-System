﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using System.threading.Task;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace MvcApplication10.Controllers
{
    public class LoginController : Controller
    {

        public SqlConnection connection { get; set; }


        //string connectionString = "Data Source=desktop-klvlk5o\\sqlexpress1;Initial Catalog=YourDatabaseName;Integrated Security=True;";


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);




        public ActionResult Login()
        {
            con.Open();
            if ((con.State & ConnectionState.Open) > 0)
            {

                //Response.Write(" connection ok !");
                con.Close();
            }


            else
            {
                //Response.Write("  no connection  !");
                con.Close();
            }
            Login udata = new Login();

            return View(udata);
        }


        //
        // GET: /login/





        //    [httppost]

        //  public ActionResult index username, password)
        // {
        //    if (username =="uid" && password == "password")
        //  {
        //   return "login successful!";
        //   }
        // else
        //{
        //  return content("invalid username or password");
        // }
        //}


        [HttpPost]
        public ActionResult Login(Login udata, string Dashboard, string logout)
        {
            //int login = personid.login;
            //string name = personid.UserName;
            //string password = personid.Password;

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("loginlist", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@userName", udata.UserName);
                cmd.Parameters.AddWithValue("@Password", udata.Password);
                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();

                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();


                if (ReturnOutput == "Login successful")
                {

                    return RedirectToAction("Dashboard", "Dashboard");
                }
                else
                {
                    ViewBag.Notification = "Login failed. Please check your username and password.";
                    ViewBag.Notification = null;

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred: " + ex.Message;
            }




            return View(udata);

        }
        // forgot password controller




        public ActionResult Forgot()
        {
            Forgot litid = new Forgot();
            return View(litid);

        }
        [HttpPost]
        public ActionResult Forgot(Forgot litid)
        {


            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("NEWCREATE", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Emailid", litid.Emailid);
                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();

                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();


                if (ReturnOutput == "Forgot successful")
                {
                    ViewBag.Notification = "Forgot successful!";
                }
                else
                {
                    ViewBag.Notification = "Forgot failed. Please check your Emailid.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred: " + ex.Message;
            }
            return View(litid);


        }

        // UserRegistration controller


        public ActionResult UserRegistration()
        {
            UserRegistration litid = new UserRegistration();
            return View(litid);
        }



        [HttpPost]

        public ActionResult UserRegistration(UserRegistration litid)
        {

            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("registrationuser", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserName", litid.UserName);
                cmd.Parameters.AddWithValue("@UserEmail", litid.UserEmail);
                cmd.Parameters.AddWithValue("@ContactNumber", litid.ContactNumber);
                cmd.Parameters.AddWithValue("@Address", litid.Address);
                cmd.Parameters.AddWithValue("@PinNumber", litid.PinNumber);

                cmd.Parameters.AddWithValue("@Password", litid.Password);

                cmd.Parameters.AddWithValue("@RetypePassword", litid.RetypePassword);


                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
                if (ReturnOutput == "Registration successful")
                {
                    ViewBag.Notification = "Registration successful!";
                }
                else
                {
                    ViewBag.Notification = ReturnOutput;
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }



            return View(litid);


        }


    }
}


//public ActionResult Registration(Registration litid)
//{

//    int UID = litid.UserID;
//    string VisitorName = litid.VisitorName;
//    string VisitorEmail = litid.VisitorEmail;
//    string VisitorCompony = litid.VisitorCompony;
//    string PurposeOfVisit = litid.PurposeOfVisit;
//    string ContactNumber = litid.ContactNumber;
//    string CheckinDate = litid.CheckinDate;
//    string CheckinTime = litid.CheckinTime;
//    string Address = litid.Address;
//    string Password = litid.Password;
//    string RetypePassword = litid.RetypePassword;


//    return View(litid);
//}












//{
//            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication1"].ConnectionString);
//            using (SqlConnection con = new SqlConnection((cs))
//            {
//            SqlCommand cmd = new SqlCommand("VerifyUserDetails", con);
//            cmd.commandtype = system.Data.CommanType.Storeprocedure;
//             cmd.Parameters.AddWithValue("@userName", textuserName.Text);
//              cmd.Parameters.AddWithValue("@password", textpassword.Text);
//                SqlParameter outputparameter = new SqlParameter();
//                 outputparameter.ParameterName"VerifyUserDetails";
//                  OutputParameter.SqlDbType = System.Data.SqlDbType.Int;
//                 OutputParameter.S = System.Data.SqlDbType.Int;











// public  List<usermodel1> put value();
//        [HttpPost]
//        public Actioresult verify (usermodel1 usr)
//        {
//          var u = putvalue(); 
//          var ue=u.Where(u=>u.username.Equals(usr.username);
//          var ue=ue.Where(p=>p.password.Equals(usr.password);
//            {
//if (up.count()==1)
// viewBag.message="login success";
// return view ("login success");
//}
//else
// viewBag.message="login failed";
// return view ("login ");
//}
//}
