﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace MvcApplication10.Controllers
{
    public class DashboardController : Controller
    {
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);




        public ActionResult Dashboard()
        {
            Dashboard litid = new Dashboard();
            return View(litid);
        }

        //[HttpPost]
        //        public ActionResult Dashboard(Dashboard litid)
        //        {


        //               try
        //    {
        //        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand("board", con);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("UserRegistration", litid.UserRegistration);
        //        cmd.Parameters.AddWithValue("Registration", litid.Registration);
        //        SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
        //        outputParam.Direction = ParameterDirection.Output;

        //        cmd.ExecuteNonQuery();
        //        con.Close();

        //        // Retrieve the output parameter value
        //        string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
        //        if (@ReturnOutput == "Login successful")
        //        {
        //            return RedirectToAction("Dashboard");
        //        }
        //        else
        //        {
        //            ViewBag.Notification = null;
        //        }
        //               }
        //    catch (Exception ex)
        //    {
        //        ViewBag.Notification = null;
        //        // Log the exception or handle it appropriately
        //    }

        //    return View(litid);
        //}
    }
}

