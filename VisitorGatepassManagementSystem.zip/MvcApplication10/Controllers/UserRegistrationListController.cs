﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;


namespace MvcApplication10.Controllers
{
    public class UserRegistrationListController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        public ActionResult UserRegistrationList()
        {
            List<UserRegistrationList> UserRegistrationListRecords = new List<UserRegistrationList>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("ListUserRegistration", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", 0);
                cmd.Parameters.AddWithValue("@UserName", "");
                cmd.Parameters.AddWithValue("@UserEmail", "");
                cmd.Parameters.AddWithValue("@ContactNumber", "");
                cmd.Parameters.AddWithValue("@Address", "");
                cmd.Parameters.AddWithValue("@PinNumber", "");
                cmd.Parameters.AddWithValue("@Password", "");
                cmd.Parameters.AddWithValue("@RetypePassword", "");



                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<UserRegistrationList> UserRegistrationList = new List<UserRegistrationList>();

                foreach (DataRow row in dt.Rows)
                {
                    UserRegistrationList User = new UserRegistrationList();
                    User.UserID = Convert.ToInt32(row["UserID"]);
                    User.UserName = row["UserName"].ToString();
                    User.UserEmail = row["UserEmail"].ToString();
                    User.ContactNumber = row["ContactNumber"].ToString();
                    User.Address = row["Address"].ToString();
                    User.PinNumber = row["PinNumber"].ToString();
                    User.Password = row["Password"].ToString();
                    User.RetypePassword = row["RetypePassword"].ToString();
                    UserRegistrationList.Add(User);
                }

                return View(UserRegistrationList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<UserRegistrationList>());
            }
        }
        // delete user

        //public class DeleteController : Controller
        //{
        //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        //    public ActionResult Delete()
        //    {
        //        Delete list = new Delete();
        //        return View(list);
        //    }
        //    [HttpPost]
        //    public JsonResult Delete(int list)
        //    {
        //        try
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("Deletelist", con);
        //            cmd.CommandType = CommandType.StoredProcedure;

        //            cmd.Parameters.AddWithValue("@UserID", list);

        //            cmd.ExecuteNonQuery();
        //            con.Close();

        //            return Json(new { success = true, message = "USer deleted successfully." });
        //        }
        //        catch (Exception ex)
        //        {
        //            // Log the error or handle it appropriately
        //            return Json(new { success = false, message = "Error deleting visitor: " + ex.Message });
        //        }
        //    }
        // UPdate user
        public ActionResult UpdateRegistration(int UserID = 0)
        {

            UserRegistrationList VisitorRegistrationobj = new UserRegistrationList();
            VisitorRegistrationobj = GetUpdateVisitorData(UserID);
            return View(VisitorRegistrationobj);
        }
        public UserRegistrationList GetUpdateVisitorData(int UserID)
        {
            UserRegistrationList VisitorRegistrationobj = new UserRegistrationList();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("User_selectone", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    //VisitorRegistrationobj.UserID = Convert.ToInt32(reader["UserID"]);
                    VisitorRegistrationobj.UserName = reader["UserName"].ToString();
                    VisitorRegistrationobj.UserEmail = reader["UserEmail"].ToString();
                    VisitorRegistrationobj.ContactNumber = reader["ContactNumber"].ToString();
                    VisitorRegistrationobj.Address = reader["Address"].ToString();
                    VisitorRegistrationobj.PinNumber = reader["PinNumber"].ToString();
                    VisitorRegistrationobj.Password = reader["Password"].ToString();
                    VisitorRegistrationobj.RetypePassword = reader["RetypePassword"].ToString();
                }
                return VisitorRegistrationobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new UserRegistrationList();
            }
        }



        [HttpPost]
        public ActionResult UpdateRegistration(UserRegistrationList VisitorRegistrationobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("[updatevisitor]", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", VisitorRegistrationobj.UserID);
                cmd.Parameters.AddWithValue("@UserName", VisitorRegistrationobj.UserName);
                cmd.Parameters.AddWithValue("@UserEmail", VisitorRegistrationobj.UserEmail);
                cmd.Parameters.AddWithValue("@ContactNumber", VisitorRegistrationobj.ContactNumber);
                cmd.Parameters.AddWithValue("@Address", VisitorRegistrationobj.Address);
                cmd.Parameters.AddWithValue("@PinNumber", VisitorRegistrationobj.PinNumber);
                cmd.Parameters.AddWithValue("@Password", VisitorRegistrationobj.Password);
                cmd.Parameters.AddWithValue("@RetypePassword", VisitorRegistrationobj.RetypePassword);



                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }

            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }

            return View(VisitorRegistrationobj);
        }
    }
}



