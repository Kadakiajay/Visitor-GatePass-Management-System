﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class SingleDay 
    {
        public int SingledayID { get; set; }
        public string VisitorName { get; set; }
        public int VisitorID { get; set; }
        public int VisitorCompany { get; set; }
        public int VisitorType { get; set; }
        public string City { get; set; }
        public string ContactNumber { get; set; }
        public TimeSpan ExpectedDuration { get; set; }
        public string PurposeOfVisit { get; set; }
        //public Guid IDNumber { get; set; } 
        public List<DropDownVisitor> lstSingleDropdown { get; set; }  
        public List<DropDownVisitorCompany> lstSingleCompanyDropdown { get; set; }
        public List<DropDownVisitor> lstSingleDropdownUpdate { get; set; }
        public List<DropDownVisitorCompany> lstSingleDropdowncomUpdate { get; set; }
    }
    public class SingleDayList
    {
        public int SingledayID { get; set; }
        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorCompany { get; set; }
        public string VisitorType { get; set; }
        public string City { get; set; }
        public string ContactNumber { get; set; }
        public string ExpectedDuration { get; set; }
        public string PurposeOfVisit { get; set; }
        public string IDNumber { get; set; } 
    }

    

    //public class UpdateSingleday
    //{

    //    public int SingledayID { get; set; }
    //    public string VisitorName { get; set; }
    //    public string VisitorCompany { get; set; }
    //    public string VisitorType { get; set; }
    //    public string City { get; set; }
    //    public string ContactNumber { get; set; }
    //    public string ExpectedDuration { get; set; }
    //    public string PurposeOfVisit { get; set; }
    //}
}
