﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcApplication10.Models;
using System.Web.Mvc;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MvcApplication10.Controllers
{

    public class AppoitmentController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        //list Appoitment



        public ActionResult AppoitmentList()
        {
            List<AppoitmentList> AppoitmentListRecords = new List<AppoitmentList>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("AppoitmentList", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<AppoitmentList> AppoitmentList = new List<AppoitmentList>();

                foreach (DataRow row in dt.Rows)
                {
                    AppoitmentList visitor = new AppoitmentList();
                    visitor.AppoitmentID = Convert.ToInt32(row["AppoitmentID"]);
                    //visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();
                    visitor.VisitorCompany = row["CompanyName"].ToString();
                    visitor.VisitorType = row["VisitorType"].ToString();
                    visitor.ContactNumber = row["ContactNumber"].ToString();
                    visitor.Date = row["Date"].ToString();
                    visitor.Time = row["Time"].ToString();


                    visitor.Duration = TimeSpan.Parse(row["Duration"].ToString());
                    visitor.PurposeofMeeting = row["PurposeofMeeting"].ToString();
                    visitor.IDNumber = row["IDNumber"].ToString();

                    AppoitmentList.Add(visitor);
                }

                return View(AppoitmentList);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<AppoitmentList>());
            }
        }


        //Craete appoitment     


        public ActionResult Appoitment()
        {
            Appoitment akay = new Appoitment();
            akay.lstVisitorDropdown = DropDownappo();
            akay.lstVisitorCompanyDropdown = DropDownVisitorCompany();

            return View(akay);
        }

        [HttpPost]
        public ActionResult Appoitment(Appoitment akay)
        {
            try
            {
                //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("TableAppoitment", con);

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@VisitorCompany", akay.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorName ", akay.VisitorID);
                cmd.Parameters.AddWithValue("@VisitorType ", akay.VisitorType);
                cmd.Parameters.AddWithValue("@ContactNumber", akay.ContactNumber ?? (object)DBNull.Value);

                cmd.Parameters.AddWithValue("@Date", akay.Date);
                //cmd.Parameters.Add("@Time", SqlDbType.Time.Value = akay.Time != null ? (object)akay.Time : DBNull.Value);
                cmd.Parameters.AddWithValue("@Time", akay.Time != null ? (object)akay.Time : DBNull.Value);

                //cmd.Parameters.AddWithValue("@Time", akay.Time ?? (object)DBNull.Value);


                cmd.Parameters.AddWithValue("@Duration", akay.Duration != null ? (object)akay.Duration : DBNull.Value);
                cmd.Parameters.AddWithValue("@PurposeofMeeting", akay.PurposeofMeeting ?? (object)DBNull.Value);


                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                akay.lstVisitorDropdown = DropDownappo();
                akay.lstVisitorCompanyDropdown = DropDownVisitorCompany();

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = " Appoitment Registration Successful";
                }
                else
                {
                    ViewBag.Notification = "User already exists";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";

            }

            return View(akay);

        }
        //DropDownVisitor

        public List<DropDownVisitor> DropDownappo()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> DropDownappo = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();
                    visitor.VisitorType = row["VisitorType"].ToString();
                    DropDownappo.Add(visitor);
                }

                //SelectList VisitorList = new SelectList(DropDownVisitor, "VisitorID", "VisitorName");

                return DropDownappo;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }
        }



        //dropdownvisitorcompany
        public List<DropDownVisitorCompany> DropDownVisitorCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Dropdowncompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownVisitorCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();
                    DropDownVisitorCompany.Add(visitor);
                }


                return DropDownVisitorCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }


        //updateApplication


        public ActionResult UpdateAppoitment(int AppoitmentID = 0)
        {
            Appoitment Visitorcompanyobj = new Appoitment();
            Visitorcompanyobj = GetUpdateAppoitmentData(AppoitmentID);
            Visitorcompanyobj.lstVisitorupdateDropdown = DropVisitor();
            Visitorcompanyobj.lstUpdateVisitorCompanyDropdown = DropDownoCompany();
            return View(Visitorcompanyobj);
        }

        public Appoitment GetUpdateAppoitmentData(int AppoitmentID)
        {
            Appoitment Visitorcompanyobj = new Appoitment();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Appoitment_selectone", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppoitmentID", AppoitmentID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Visitorcompanyobj.AppoitmentID = Convert.ToInt32(reader["AppoitmentID"]);
                    Visitorcompanyobj.VisitorID = Convert.ToInt32(reader["VisitorID"]);
                    Visitorcompanyobj.VisitorType = Convert.ToInt32(reader["VisitorType"].ToString());
                    Visitorcompanyobj.VisitorCompany = Convert.ToInt32(reader["VisitorCompany"].ToString());
                    Visitorcompanyobj.Date = Convert.ToDateTime(reader["Date"]);
                    Visitorcompanyobj.Time = TimeSpan.Parse(reader["Time"].ToString());
                    //Visitorcompanyobj.TimeAsString = reader["TimeAsString"].ToString();
                    Visitorcompanyobj.Duration = TimeSpan.Parse(reader["Duration"].ToString());
                    Visitorcompanyobj.ContactNumber = reader["ContactNumber"].ToString();
                    Visitorcompanyobj.PurposeofMeeting = reader["PurposeofMeeting"].ToString();

                }
                con.Close();
                return Visitorcompanyobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new Appoitment();
            }
        }

        [HttpPost]

        public ActionResult UpdateAppoitment(Appoitment Visitorcompanyobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("UpdateAppoitment", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppoitmentID", Visitorcompanyobj.AppoitmentID);
                cmd.Parameters.AddWithValue("@VisitorName", Visitorcompanyobj.VisitorID);
                cmd.Parameters.AddWithValue("@VisitorCompany", Visitorcompanyobj.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorType", Visitorcompanyobj.VisitorType);
                cmd.Parameters.AddWithValue("@ContactNumber", Visitorcompanyobj.ContactNumber);
                cmd.Parameters.AddWithValue("@Date", Visitorcompanyobj.Date);
                cmd.Parameters.AddWithValue("@Time", Visitorcompanyobj.Time);
                cmd.Parameters.AddWithValue("@Duration", Visitorcompanyobj.Duration);

                cmd.Parameters.AddWithValue("@PurposeofMeeting", Visitorcompanyobj.PurposeofMeeting);




                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                Visitorcompanyobj.lstVisitorupdateDropdown = DropVisitor();
                Visitorcompanyobj.lstUpdateVisitorCompanyDropdown = DropDownoCompany();
                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();


                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }

            return View(Visitorcompanyobj);

        }

        //DropDownUpdateVisitor
        public List<DropDownVisitor> DropVisitor()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropDOwnVisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitor> DropVisitor = new List<DropDownVisitor>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitor visitor = new DropDownVisitor();
                    visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    visitor.VisitorName = row["VisitorName"].ToString();

                    visitor.VisitorType = row["VisitorType"].ToString();

                    DropVisitor.Add(visitor);
                }

                return DropVisitor;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitor>();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        //UPDATEVISITORCOMPANY
        public List<DropDownVisitorCompany> DropDownoCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Dropdowncompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownoCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();
                    DropDownoCompany.Add(visitor);
                }


                return DropDownoCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }



    }
}

