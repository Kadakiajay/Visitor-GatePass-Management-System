﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;


namespace MvcApplication10.Controllers
{
    public class VisitorRegistrationController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        //Visitor List
        public ActionResult Visitorlist()
        {
            List<Visitorlist> VisitorRecords = new List<Visitorlist>();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("listvisitor", con);
                cmd.CommandType = CommandType.StoredProcedure;

                // cmd.Parameters.AddWithValue("@VisitorID", 0);
                cmd.Parameters.AddWithValue("@VisitorName", "");
                cmd.Parameters.AddWithValue("@VisitorEmail", "");
                cmd.Parameters.AddWithValue("@VisitorCompany", "");
                cmd.Parameters.AddWithValue("@VisitorType", "");
                cmd.Parameters.AddWithValue("@DateOfBirth", "");
                cmd.Parameters.AddWithValue("@ContactNumber", "");
                cmd.Parameters.AddWithValue("@Country", "");
                cmd.Parameters.AddWithValue("@State", "");
                cmd.Parameters.AddWithValue("@City", "");
                cmd.Parameters.AddWithValue("@Address", "");

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<Visitorlist> Visitorlist = new List<Visitorlist>();

                foreach (DataRow row in dt.Rows)
                {
                    Visitorlist Visitor = new Visitorlist();
                    Visitor.VisitorID = Convert.ToInt32(row["VisitorID"]);
                    Visitor.VisitorName = row["VisitorName"].ToString();
                    Visitor.VisitorEmail = row["VisitorEmail"].ToString();
                    Visitor.VisitorCompany = row["CompanyName"].ToString();
                    Visitor.VisitorType = row["VisitorType"].ToString();
                    Visitor.DateOfBirth = Convert.ToDateTime(row["DateOfBirth"]);
                    Visitor.ContactNumber = row["ContactNumber"].ToString();
                    Visitor.Country = row["Country"].ToString();
                    Visitor.State = row["State"].ToString();
                    Visitor.City = row["City"].ToString();
                    Visitor.Address = row["Address"].ToString();
                    Visitorlist.Add(Visitor);
                }

                return View(Visitorlist);
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;



                return View(new List<Visitorlist>());
            }
        }

        //Create Visitor
        public ActionResult VisitorRegistration()
        {
            VisitorRegistration litid = new VisitorRegistration();
            litid.lstVisitorCompanyDropdown = DropDownVisitorCompany();
            return View(litid);
        }

        [HttpPost]
        public ActionResult VisitorRegistration(VisitorRegistration litid)
        {

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("RegistrationVisitor", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VisitorName", litid.VisitorName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@VisitorEmail", litid.VisitorEmail ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@VisitorCompany", litid.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorType", litid.VisitorType ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DateOfBirth", litid.DateOfBirth);
                cmd.Parameters.AddWithValue("@ContactNumber", litid.ContactNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Country", litid.Country ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@State", litid.State ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@City", litid.City ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Address", litid.Address ?? (object)DBNull.Value);

                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
                litid.lstVisitorCompanyDropdown = DropDownVisitorCompany();
                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = " Visitor  Registration Successful";
                }
                else
                {
                    ViewBag.Notification = "User already exists";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred:+ ex.Message";
            }
            return View(litid);

        }
        //DropDownCompay

        public List<DropDownVisitorCompany> DropDownVisitorCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Dropdowncompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownVisitorCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();

                    DropDownVisitorCompany.Add(visitor);
                }

                return DropDownVisitorCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }

        //Delete user

        //[HttpPost]
        //public JsonResult Delete(int VisitorID)
        //{
        //    try
        //    {
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand("Deletelist", con);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@VisitorID", VisitorID);

        //        cmd.ExecuteNonQuery();
        //        con.Close();

        //        return Json(new { success = true, message = "Visitor deleted successfully." });
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the error or handle it appropriately
        //        return Json(new { success = false, message = "Error deleting visitor: " + ex.Message });
        //    }
        //}

        ////Dropdowncompany
        //public List<DropDownVisitorCompany> Dropdowncompany()
        //{
        //    try
        //    {
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand("Dropdowncompany", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        DataTable dt = new DataTable();
        //        dt.Load(cmd.ExecuteReader());
        //        con.Close();

        //        List<DropDownVisitorCompany> Dropdowncompany = new List<DropDownVisitorCompany>();

        //        foreach (DataRow row in dt.Rows)
        //        {
        //            DropDownVisitorCompany company = new DropDownVisitorCompany();
        //            company.VisitorCompanyID = Convert.ToInt32(row["CompanyId"]);
        //            company.VisitorCompanyName = row["CompanyName"].ToString();

        //            Dropdowncompany.Add(company);
        //        }

        //        return Dropdowncompany;
        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
        //        return new List<DropDownVisitorCompany>();
        //    }
        //}
        //Update User
        public ActionResult Update(int VisitorID = 0)
        {

            VisitorRegistration VisitorRegistrationobj = new VisitorRegistration();
            VisitorRegistrationobj = GetUpdateVisitorData(VisitorID);
            VisitorRegistrationobj.lstVisitorDropdowncomUpdate = DropDownCompany();
            return View(VisitorRegistrationobj);
        }
        public VisitorRegistration GetUpdateVisitorData(int VisitorID)
        {
            VisitorRegistration VisitorRegistrationobj = new VisitorRegistration();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Visitor_SelectOne", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VisitorID", VisitorID);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    VisitorRegistrationobj.VisitorID = Convert.ToInt32(reader["VisitorID"]);
                    VisitorRegistrationobj.VisitorName = reader["VisitorName"].ToString();
                    VisitorRegistrationobj.VisitorEmail = reader["VisitorEmail"].ToString();
                    VisitorRegistrationobj.VisitorCompany = Convert.ToInt32(reader["VisitorCompany"].ToString());
                    VisitorRegistrationobj.VisitorType = reader["VisitorType"].ToString();
                    VisitorRegistrationobj.DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]);
                    VisitorRegistrationobj.ContactNumber = reader["ContactNumber"].ToString();
                    VisitorRegistrationobj.Country = reader["Country"].ToString();
                    VisitorRegistrationobj.State = reader["State"].ToString();
                    VisitorRegistrationobj.City = reader["City"].ToString();
                    VisitorRegistrationobj.Address = reader["Address"].ToString();
                }
                return VisitorRegistrationobj;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new VisitorRegistration();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


        }



        [HttpPost]
        public ActionResult Update(VisitorRegistration VisitorRegistrationobj)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Updatelist", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VisitorID", VisitorRegistrationobj.VisitorID);
                cmd.Parameters.AddWithValue("@VisitorName", VisitorRegistrationobj.VisitorName);
                cmd.Parameters.AddWithValue("@VisitorEmail", VisitorRegistrationobj.VisitorEmail);
                cmd.Parameters.AddWithValue("@VisitorCompany", VisitorRegistrationobj.VisitorCompany);
                cmd.Parameters.AddWithValue("@VisitorType", VisitorRegistrationobj.VisitorType);
                cmd.Parameters.AddWithValue("@DateOfBirth", VisitorRegistrationobj.DateOfBirth);
                cmd.Parameters.AddWithValue("@ContactNumber", VisitorRegistrationobj.ContactNumber);
                cmd.Parameters.AddWithValue("@Country", VisitorRegistrationobj.Country);
                cmd.Parameters.AddWithValue("@State", VisitorRegistrationobj.State);
                cmd.Parameters.AddWithValue("@City", VisitorRegistrationobj.City);
                cmd.Parameters.AddWithValue("@Address", VisitorRegistrationobj.Address);


                SqlParameter outputParam = cmd.Parameters.Add("@ReturnOutput", SqlDbType.NVarChar, 100);
                outputParam.Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();
                con.Close();
                string ReturnOutput = cmd.Parameters["@ReturnOutput"].Value.ToString();
                VisitorRegistrationobj.lstVisitorDropdowncomUpdate = DropDownCompany();

                if (ReturnOutput.ToLower().Contains("successful"))
                {
                    ViewBag.Notification = "Form Update successfully!";
                }
                else
                {
                    ViewBag.Notification = "Form Data  Unchanged!";

                }
            }
            catch (Exception ex)
            {
                ViewBag.Notification = "An error occurred: " + ex.Message;
            }

            return View(VisitorRegistrationobj);
        }
        public List<DropDownVisitorCompany> DropDownCompany()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DropdownCompany", con);
                cmd.CommandType = CommandType.StoredProcedure;

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                con.Close();

                List<DropDownVisitorCompany> DropDownCompany = new List<DropDownVisitorCompany>();

                foreach (DataRow row in dt.Rows)
                {
                    DropDownVisitorCompany visitor = new DropDownVisitorCompany();
                    visitor.VisitorCompanyID = Convert.ToInt32(row["CompanyID"]);
                    visitor.VisitorCompanyName = row["CompanyName"].ToString();

                    DropDownCompany.Add(visitor);
                }

                return DropDownCompany;
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An error occurred: " + ex.Message;
                return new List<DropDownVisitorCompany>();
            }
        }
    }
}








