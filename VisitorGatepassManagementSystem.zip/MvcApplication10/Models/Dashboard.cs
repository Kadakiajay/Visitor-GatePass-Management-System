﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class Dashboard 
    {
        public int UserID { get; set; }
        public string UserRegistration { get; set; }
        public string Registration { get; set; }

       
    }
}
