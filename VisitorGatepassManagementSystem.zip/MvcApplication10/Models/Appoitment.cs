﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace MvcApplication10.Models
{
    public class Appoitment
    {
        public int AppoitmentID { get; set; }
        public int VisitorID { get; set; }
        public int VisitorName { get; set; }
        public int VisitorCompany { get; set; }
        public int VisitorType { get; set; }
        public string ContactNumber { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public TimeSpan Duration { get; set; } 
        public string PurposeofMeeting { get; set; }
        public List<DropDownVisitor> lstVisitorDropdown { get; set; }
        public List<DropDownVisitorCompany> lstVisitorCompanyDropdown { get; set; }
        public List<DropDownVisitor> lstVisitorupdateDropdown { get; set; }
        public List<DropDownVisitorCompany> lstUpdateVisitorCompanyDropdown { get; set; }
     
 
        
    }
    public class AppoitmentList
    {
        public int AppoitmentID { get; set; }
        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorCompany { get; set; }
        public string VisitorType { get; set; }
        public string ContactNumber { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public TimeSpan Duration { get; set; }
        public string PurposeofMeeting { get; set; }
        public string IDNumber { get; set; } 
    }
    public class DropDownVisitor
    {

        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorType { get; set; }


    }
    public class DropDownVisitorCompany
    {

        public int VisitorCompanyID { get; set; }
        public string VisitorCompanyName { get; set; }


    }
    public class UpdateAppoitment
    {
        public int AppoitmentID { get; set; }
        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public int VisitorCompany { get; set; }
        public int VisitorType { get; set; }
        public string ContactNumber { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public TimeSpan Duration { get; set; }
        public string PurposeofMeeting { get; set; }
    }
    
    
}
