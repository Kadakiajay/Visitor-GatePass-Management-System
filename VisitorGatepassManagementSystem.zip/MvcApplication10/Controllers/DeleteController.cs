﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication10.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace MvcApplication10.Controllers
{
    public class DeleteController : Controller
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MvcApplication10"].ConnectionString);

        public ActionResult Delete()
        {
            Delete list = new Delete();
            return View(list);
        }
        [HttpPost]
        public JsonResult Delete(int list)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Deletelist", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", list);
                cmd.Parameters.AddWithValue("@CompanyID ", list);
                cmd.Parameters.AddWithValue("@VisitorID ", list);
                cmd.Parameters.AddWithValue("@AppoitmentID ", list);
                cmd.Parameters.AddWithValue("@SingledayID", list);
                cmd.Parameters.AddWithValue("@MultipledayID ", list);
                cmd.ExecuteNonQuery();
                con.Close();

                return Json(new { success = true, message = "Visitor deleted successfully." });
            }
            catch (Exception ex)
            {
                // Log the error or handle it appropriately
                return Json(new { success = false, message = "Error deleting visitor: " + ex.Message });
            }
        }
    }
}