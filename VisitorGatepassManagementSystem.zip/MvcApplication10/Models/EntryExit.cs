﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class EntryExit
    {
        public String IDNumber { get; set; }
        public int TranscationID { get; set; }
        public int TranscationType { get; set; }
        public String VisitorCompany { get; set; }
        public String VisitorName { get; set; }


    }
    //public class ExitEntry
    //{

    //    public String IDNumber { get; set; }
    //    public int TranscationType { get; set; }

    //    //public int TranscationType { get; set; }
    //    public String VisitorCompany { get; set; }
    //    public String VisitorName { get; set; }

    //}
     public class PassEntryExit 
    {
       public int EntryExitID { get; set; }
        public int EntryExitType { get; set; }
        public int PassType { get; set; } 
        public int RefID { get; set; }
        public string IDNumber { get; set; }
        
        }
     public class EntryExitList
     {
         public int EntryExitID { get; set; }
         public String VisitorName { get; set; }
         public String VisitorCompany { get; set; }
         public String EntryExitType { get; set; }
     }
 }





