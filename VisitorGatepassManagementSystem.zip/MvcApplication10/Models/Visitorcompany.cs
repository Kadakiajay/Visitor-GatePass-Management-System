﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class Visitorcompany 
    {


        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyEmail { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyPhone { get; set; }
        public string PinCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string GSTNUMBER { get; set; }

    }
    public class VisitorcompanyList
    {

        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyEmail { get; set; }
        public string CompanyAddress { get; set; }
        public string CompanyPhone { get; set; }
        public string PinCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string GSTNUMBER { get; set; }

    }
    //public class UpdateCompany
    //{
    //    public int CompanyID { get; set; }
    //    public string CompanyName { get; set; }
    //    public string CompanyEmail { get; set; }
    //    public string CompanyAddress { get; set; }
    //    public string CompanyPhone { get; set; }
    //    public string PinCode { get; set; }
    //    public string City { get; set; }
    //    public string State { get; set; }
    //    public string Country { get; set; }
    //    public string GSTNUMBER { get; set; }

    //}
}
