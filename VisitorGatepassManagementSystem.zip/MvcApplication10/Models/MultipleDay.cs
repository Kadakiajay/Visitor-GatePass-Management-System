﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication10.Models
{
    public class MultipleDay 
    {
        public int MultipledayID { get; set; }
        public int VisitorID { get; set; }
        public string VisitorName { get; set; } 
        public string VisitorType { get; set; }
        public string VisitorCompany { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime TODate { get; set; }
        public string ContactNumber { get; set; }
        public string City { get; set; }
        public List<DropDownVisitor> lstMultipleDropdown { get; set; }
        public List<DropDownVisitorCompany> lstMultipleCompanyDropdown { get; set; }
        public List<DropDownVisitor> lstMultipleDropdownupdate { get; set; }
        public List<DropDownVisitorCompany> lstMultipleCompanyDropdownupdate { get; set; }
    }

    public class MultipleDayList
    {

        public int MultipledayID { get; set; }
        public int VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorType { get; set; }
        public string VisitorCompany { get; set; }
        public string FromDate { get; set; }
        public string TODate { get; set; }
        public string ContactNumber { get; set; }
        public string City { get; set; }
        public string IDNumber { get; set; } 


    }
   

    //public class UpdateMultipleday
    //{

    //    public int MultipledayID { get; set; }
    //    public string VisitorName { get; set; }
    //    public string VisitorType { get; set; }
    //    public string VisitorCompany { get; set; }
    //    public DateTime FromDate { get; set; }
    //    public DateTime TODate { get; set; }
    //    public string ContactNumber { get; set; }
    //    public string City { get; set; }



    //}

}
